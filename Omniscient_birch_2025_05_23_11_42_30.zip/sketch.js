let player;
let obstacles = [];
let score = 0;
let gameOver = false;

function setup() {
  createCanvas(800, 600);
  player = new Player(width / 2, height - 50);
}

function draw() {
  background(0); // Cor de fundo preta
  
  if (gameOver) {
    fill(255);
    textSize(48);
    textAlign(CENTER);
    text("Fim de Jogo!", width / 2, height / 2 - 50);
    textSize(24);
    text("Pontuação: " + score, width / 2, height / 2);
    return;
  }
  
  // Desenhar o jogador
  player.display();
  
  // Criar obstáculos
  if (frameCount % 60 === 0) {
    obstacles.push(new Obstacle(random(width), 0, random(30, 70), random(2, 5)));
  }
  
  // Mover e desenhar obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].move();
    obstacles[i].display();
    
    // Verifica colisão com o jogador
    if (player.hits(obstacles[i])) {
      gameOver = true; // O jogo termina se houver colisão
    }
    
    // Verifica se o obstáculo saiu da tela
    if (obstacles[i].y > height) {
      obstacles.splice(i, 1); // Remove o obstáculo se sair da tela
      score++; // Aumenta a pontuação
    }
  }
  
  // Exibir pontuação
  fill(255);
  textSize(24);
  text("Pontuação: " + score, 10, 30);
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    player.move(-15); // Move o jogador para a esquerda
  } else if (keyCode === RIGHT_ARROW) {
    player.move(15); // Move o jogador para a direita
  }
}

class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 40;
  }

  display() {
    fill(0, 255, 0); // Cor do jogador
    rect(this.x, this.y, this.size, this.size); // Representação do jogador
  }

  move(dir) {
    this.x += dir;
    this.x = constrain(this.x, 0, width - this.size); // Limitar movimento dentro da tela
  }

  hits(obstacle) {
    return (this.x < obstacle.x + obstacle.size && this.x + this.size > obstacle.x && this.y < obstacle.y + obstacle.size && this.y + this.size > obstacle.y); // Verifica colisão com o obstáculo
  }
}

class Obstacle {
  constructor(x, y, size, speed) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.speed = speed;
  }

  move() {
    this.y += this.speed; // Move o obstáculo para baixo
  }

  display() {
    fill(255, 0, 0); // Cor do obstáculo
    rect(this.x, this.y, this.size, this.size); // Representação do obstáculo
  }
}
